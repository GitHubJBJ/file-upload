package com.liren.imgtool.tools;

import com.liren.imgtool.exception.ImgToolException;
import com.sun.imageio.plugins.common.ImageUtil;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedList;

/**
 * @description: 测试切图
 * @author: Mr.Wang
 * @create time: on 2019-10-18 17:28
 **/

public class CutImgTest {

    public static void main(String[] args) throws Exception {

        cut1();
//        cut2();
    }

    private static void cut2() throws Exception {
        String url = "http://gzhimages.paidanzi.com/Img/0da77783-0b6d-4235-9be9-0f44451864ee/1571295969574/1.jpg";
//        String url = "http://gzhimages.paidanzi.com/cut/fcc69b6f-4d4f-4aca-8768-b626e5e25cd0/0_0.jpg";
        InputStream inputStream = ImageUtils.imgUrlToInputStream(url);
        BufferedImage bufferedImage = ImageUtils.inStreamToBufferImg(inputStream);
//        LinkedList<BufferedImage> biList = ImageUtils.cutImgType(bufferedImage, true, 2, 4, 0, 0);
        LinkedList<BufferedImage> biList = ImageUtils.cutImgType(bufferedImage, false, 0, 0, 500, 20000);
        for (int i = 0; i < biList.size(); i++) {
            String p = "C://lzz//cut//no_" + i + ".png";
            ImageUtils.BufferedImageToFile(biList.get(i),p);
        }

    }

    private static void cut1() throws Exception{
        //        String url = "http://gzhimages.paidanzi.com/Img/0da77783-0b6d-4235-9be9-0f44451864ee/1571295969574/1.jpg";
//        String url = "http://gzhimages.paidanzi.com/cut/fcc69b6f-4d4f-4aca-8768-b626e5e25cd0/0_0.jpg";
        String url = "C:/lzz/cut/0_0.jpg";
//        String url = "C:/lzz/cut/1.jpg";
//        InputStream inputStream = ImageUtils.imgUrlToInputStream(url);
        BufferedImage bufferedImage = ImageUtils.ImgFileToBufferImg(url);
//        BufferedImage bufferedImage = ImageUtils.inStreamToBufferImg(inputStream);
//        LinkedList<BufferedImage> biList = ImageUtils.cutImgType(bufferedImage, true, 2, 4, 0, 0);
        LinkedList<BufferedImage> biList = ImageUtils.cutImgType(bufferedImage, false, 0, 0, 500, 20000);
        for (int i = 0; i < biList.size(); i++) {
            String p = "C://lzz//cut//no_" + i + ".png";
            File file = ImageUtils.BufferedImageToFile(biList.get(i), p);
        }
    }
}
