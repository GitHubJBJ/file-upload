package com.liren.common.entity;

/**
 * @description:
 * @author: Mr.Wang
 * @create time: on 2019-10-30 17:00
 **/

public class User {
    private int id;
    private String name;

    public User() {
        id = 0;
        name = "0";
    }

    public int getId() {
        return this.id;

    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return this.name;

    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
}
