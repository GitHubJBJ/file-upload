package com.liren.imooc.clone;

/**
 * @description: <h1>shallowClone </h1>
 * @author: LiRen
 * @create time: on 2020-03-09 14:15
 **/

public class shallowClone {

    public static void main(String[] args) {

        char[] str = "abcdefg".toCharArray();
        int offset = 1;
        cutChar(str, 1);

    }

    private static void cutChar(char[] str, int offset) {
        if (str.length == 0 || offset == 0) {
            return;
        }
        int num = offset % str.length;
        for (int i = 0; i < num; i++) {
            char b = str[str.length - 1];
            for (int j = str.length - 1; j > 0; j--) {
                str[j] = str[j - 1];
            }
            str[0] = b;
        }

    }

}
