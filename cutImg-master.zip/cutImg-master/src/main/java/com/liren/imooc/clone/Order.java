package com.liren.imooc.clone;

import lombok.Data;

import java.util.List;

/**
 * @description: <h1>Order </h1>
 * @author: LiRen
 * @create time: on 2020-03-09 14:10
 **/

@Data
public class Order {
    private Long id;

    private String orderNo;

    private List<Item> itemList;


}
