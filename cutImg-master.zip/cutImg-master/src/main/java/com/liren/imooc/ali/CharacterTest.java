package com.liren.imooc.ali;

/**
 * @description: <h1>CharacterTest 包装类缓存</h1>
 * @author: LiRen
 * @create time: on 2020-03-06 17:07
 **/

public class CharacterTest {

    public static void main(String[] args) {

        Character a = 126, b = 126, c = 128, d = 128;
        System.out.println(a == b);
        System.out.println(c == d);

    }

}