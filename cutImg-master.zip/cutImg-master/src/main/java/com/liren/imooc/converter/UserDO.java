package com.liren.imooc.converter;

import lombok.Data;

import java.util.Date;

/**
 * @description: <h1>UserDO </h1>
 * @author: LiRen
 * @create time: on 2020-03-09 15:45
 **/

@Data
public class UserDO {
    private Long id;
    private String name;
    private Integer age;
    private String nickName;
    private Date birthDay;
}
