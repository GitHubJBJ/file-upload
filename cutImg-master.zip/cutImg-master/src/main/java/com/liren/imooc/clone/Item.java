package com.liren.imooc.clone;

import lombok.Data;

/**
 * @description: <h1>Item </h1>
 * @author: LiRen
 * @create time: on 2020-03-09 14:11
 **/
@Data
public class Item {
    private Long id;

    private Long itemId;

    private String name;

    private String desc;

}
