package com.liren.thread;

/**
 * @description:
 * @author: Mr.Wang
 * @create time: on 2019-10-30 16:47
 **/

public class CreateThread3  implements  Runnable{

    public static void main(String[] args) {
        Thread t1 = new Thread(new CreateThread3());
        t1.start();
    }

    @Override
    public void run() {
        System.out.println("hello I am Liren");
    }
}
