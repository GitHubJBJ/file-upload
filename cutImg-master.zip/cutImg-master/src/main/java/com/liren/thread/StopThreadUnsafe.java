package com.liren.thread;

import com.liren.common.entity.User;

/**
 * @description: 停止线程
 * @author: Mr.Wang
 * @create time: on 2019-10-30 16:57
 **/

public class StopThreadUnsafe {
    public static User user = new User();

}
