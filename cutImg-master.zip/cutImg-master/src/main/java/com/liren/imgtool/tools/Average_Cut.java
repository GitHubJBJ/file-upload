package com.liren.imgtool.tools;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * @description: 平均分割
 * @author: LiRen
 * @create time: on 2019-10-17 09:58
 **/

public class Average_Cut {

    public static void main(String[] args) {
        // 等分
        String imgUrl = "http://gzhimages.paidanzi.com/cut/df82e088-7236-4b76-a07f-9bc8f3307c2b/0_0.jpg";
//        String imgUrl = "http://gzhimages.paidanzi.com/Img/0da77783-0b6d-4235-9be9-0f44451864ee/1571295969574/1.jpg";
//        String imgUrl = "C:/lzz/data/0_0.jpg";
        Integer destWidth = 0;
        Integer destHeight = 0;
        getImage(imgUrl, destWidth, destHeight);
    }

    private static void getImage(String imgUrl, Integer destWidth, Integer destHeight) {
        try {

            List<String> list = new ArrayList<String>();
            String fileType = ".jpg";
            BufferedImage bi;
            URL urlImg = new URL(imgUrl);
            InputStream in = urlImg.openStream();
            bi = ImageIO.read(in);
            int srcWidth = bi.getWidth();
            int srcHeight = bi.getHeight();
            Integer cols = 2;
            Integer rows = 4;
            final Integer cutNum = 20000;
            if (srcHeight > cutNum) {
                //  那么将按照2W一切。 如5W的高度。那么需要按照切三次。
                rows = srcHeight /cutNum + 1;
            }
            destWidth = srcWidth / cols;    // j    500
            destHeight = cutNum;   // i    1W

            System.out.println("destHeight = " + destHeight + "，destWidth：" + destWidth);
            //	循环建立切片
            System.out.println("rows = " + rows + ",cols: " + cols);
            for (int i = 0; i < rows; i++) {
                // 四个参数分别为图像起点坐标和宽高
                if (rows - 1 == i) {
                    destHeight = srcHeight - destHeight * (i);
                }
                for (int j = 0; j < cols; j++) {
                    Image image = bi.getSubimage(j * destWidth, i * cutNum, destWidth, destHeight);
                    BufferedImage tag = new BufferedImage(destWidth, destHeight, BufferedImage.TYPE_INT_RGB);
                    Graphics g = tag.getGraphics();
                    g.drawImage(image, 0, 0, destWidth,  destHeight, null);
                    g.dispose();
                    ByteArrayOutputStream byOut = new ByteArrayOutputStream();
                    ImageIO.write(tag, "JPEG", byOut);
                    byte[] imgBytes = byOut.toByteArray();
                    String p = "C://lzz//cut//no_" + i + "_" + j + ".png";
                    ImageIO.write(tag, "JPEG", new File(p));
                    System.out.println("p = " + p);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
