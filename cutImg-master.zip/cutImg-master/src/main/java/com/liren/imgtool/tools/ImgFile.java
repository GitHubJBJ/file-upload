package com.liren.imgtool.tools;

import org.apache.commons.lang3.StringUtils;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * @description: 生成图片
 * @author: Mr.Wang
 * @create time: on 2019-10-20 15:56
 **/

public class ImgFile {

    private BufferedImage bufferedImage;
    private String path;

    public ImgFile() {
        this.bufferedImage = bufferedImage;
        this.path = path;
    }

    protected File  BufferedImageToFile(BufferedImage bi, String path) throws IOException {
        if (StringUtils.isBlank(path)) {
            return null;
        }
        ImageIO.write(bi, "JPEG", new File(path));
        File file = new File(path);
        return file;
    }
}
