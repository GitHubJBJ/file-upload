package com.liren.imgtool.exception;

/**
 * @description: 错误类型
 * @author: Mr.Wang
 * @create time: on 2019-10-18 14:48
 **/

public enum EmImgToolError implements  CommonError{
    //  通用的错误类型10001
    PARAMETER_VALIDATION_ERROR(10001, "参数不合法"),
    WIDTH_PARM_ERROR(10002, "列数错误"),
    HEIGHT_PARM_ERROR(10003, "行数错误"),
    UNKNOWN_ERROR(10004, "未知错误"),

    //  JDK的已知的错误 20000开头
    //  ★★★https://bugs.openjdk.java.net/browse/JDK-7132728
    JDK_BUGS_ARRAY_OUT_OF(30001,"JDK BUG数组越界"),

    //  30000开头位用户操作相关错误定义
    USER_NOT_EXIST(20001, "操作切图失败");

    private int errCode;
    private String errMsg;

    EmImgToolError(int errCode, String errMsg) {
        this.errCode = errCode;
        this.errMsg = errMsg;
    }

    @Override
    public int getErrCode() {
        return this.errCode;
    }

    @Override
    public String getErrMsg() {
        return this.errMsg;
    }

    @Override
    public CommonError setErrMsg(String errMsg) {
        this.errMsg = errMsg;
        return this;
    }
}
