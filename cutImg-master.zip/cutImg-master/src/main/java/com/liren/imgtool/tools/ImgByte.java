package com.liren.imgtool.tools;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * @description: BufferedImage -> 转换成Byte。方便上传
 * @author: Mr.Wang
 * @create time: on 2019-10-20 16:46
 **/

public class ImgByte {

    private BufferedImage bufferedImage;

    public ImgByte() {

    }

    public ImgByte(BufferedImage bufferedImage) {
        this.bufferedImage = bufferedImage;
    }

    protected byte[] BufferedImageToByte(BufferedImage bi) throws IOException {
        ByteArrayOutputStream byOut = new ByteArrayOutputStream();
        ImageIO.write(bi, "JPEG", byOut);
        byte[] imgBytes = byOut.toByteArray();
        return imgBytes;
    }

}
