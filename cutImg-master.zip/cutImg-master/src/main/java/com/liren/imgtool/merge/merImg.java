package com.liren.imgtool.merge;

import com.alibaba.fastjson.JSON;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.*;
import java.util.List;

/**
 * @description: 合并图片
 * 1、要计算，整个图片的大小
 * 2、要计算图片是否超过尺寸 2W
 * 3、要控制好坐标起点。
 * ★★★★★注意：是否有被省略的缩进，可能会出现。图片像素丢失  也就是说图像发生了错位。
 * 4、要输出完整的图片 BufferedImage （可以考虑使用线程）★★★★★ 但是有可能会造成内存泄露或者 变量共享
 * 5、要上传到服务器
 * 6、要存到redis（可选）暴露对外的key
 * @author: Mr.Wang
 * @create time: on 2019-10-29 15:33
 **/
@SuppressWarnings("all")
public class merImg {

    public static void main(String[] args) throws IOException {
        //  step 1
        //  首先要从前端获得 拼接的图片下信息
        //  拿到正确的图像布局之后，就可以画图了。
        //  但是整图的坐标怎么拿到

        //  step 2
        //  退而求其次，可以把一次切割的合并成一个整图。 可以根据返回的img_id来区分是那次切割的
        //  可以拿到切割的图像信息。 x、y、w、h。也就是说可以初步的拿到合并后的图像的x、y、w、h数据。但是存在被缩放的可能

        //  step 3
        //  将一次切割合并。2019年10月29日 16:34:33
        String parm = createParm();
        System.out.println("parm = " + parm);
        //  解析成每个都拆分
        List<Map> list = JSON.parseArray(parm, Map.class);
        for (int i = 0; i < list.size(); i++) {
            Map map = list.get(i);
            Integer cutNum = Integer.valueOf(String.valueOf(map.get("cutNum")));
            Boolean cutType = Boolean.valueOf(String.valueOf(map.get("cutType")));
            String cutImgUrl = String.valueOf(map.get("cutImgUrl"));
            List<String> cImg = Arrays.asList(cutImgUrl.split(","));
            //  最终绘图的宽和高
            Integer mWidth = 0;
            Integer mHeight = 0;
            List<Object> imgList = new LinkedList<>();
            List<Integer> widthList = new LinkedList<>();
            List<Integer> heightList = new LinkedList<>();
            //  纵向切图
            if (cutType) {
                //  说明高度不变，宽度需要累加
                for (int j = 0; j < cImg.size(); j++) {
                    String s = cImg.get(j);
                    URL urlImg = new URL(s);
                    InputStream in = urlImg.openStream();
                    Image img = ImageIO.read(in);
                    int w = img.getWidth(null);
                    int h = img.getHeight(null);
                    mWidth += w;
                    mHeight = h;
                    imgList.add(img);
                    widthList.add(w);
                }
            } else {
                //  横切，再说吧。
            }
            //  开始拼接图像
            BufferedImage tag = new BufferedImage(mWidth, mHeight, BufferedImage.TYPE_INT_RGB);
            String p = "C://lzz//cut//no_" + cutType + ".png";
            //  创建输出流
//            FileOutputStream out = new FileOutputStream(p);
            //  绘制图像
            Graphics2D g = tag.createGraphics();
            //  每次绘图的宽和高
            Integer cWidth = 0;
            Integer cHeight = 0;
            System.out.println("mWidth，" + mWidth + ",mHeight," + mHeight);
            for (int j = 0; j < imgList.size(); j++) {
                Image image = (Image) imgList.get(j);
                if (cutType) {
                    //  纵切，纵坐标不变，但是横坐标需要累加。从0开始
                    Integer width = widthList.get(j);
                    cWidth += width;
                    //  最后一次的宽度发生了变化。
//                    g.drawImage(image, cWidth - baseW, 0, width, mHeight, null);
                    g.drawImage(image, cWidth - width, 0, width, mHeight, null);
                } else {
                    //  横切，横坐标不变，纵坐标累加
                }
            }
            //  但是在最后一次的宽高拼接中，由于最后一次宽高的不同。导致目前的切割算法中，会出现一条黑线，猜测可能是
            //  底图是有100px的宽。但是图像元素绘制了98px的。所以导致出现2px的黑边像素。
            g.dispose();
            ImageIO.write(tag, "JPEG", new File(p));
        }
    }

    /**
     * 造数据
     *
     * @Return: java.lang.String
     * @Author: Mr.Wang
     * @Date: 2019/10/29
     */
    private static String createParm() {
        //  开始造数据。
        LinkedList<Map> list = new LinkedList<>();
        Map<String, Object> map2 = new LinkedHashMap<>();
        map2.put("cutImgUrl", "http://gzhimages.paidanzi.com/cut/287df17b-d323-4558-b6fb-d58293acc2bc/2_1.jpg,http://gzhimages.paidanzi.com/cut/287df17b-d323-4558-b6fb-d58293acc2bc/2_2.jpg,http://gzhimages.paidanzi.com/cut/287df17b-d323-4558-b6fb-d58293acc2bc/2_3.jpg,http://gzhimages.paidanzi.com/cut/287df17b-d323-4558-b6fb-d58293acc2bc/2_4.jpg,http://gzhimages.paidanzi.com/cut/287df17b-d323-4558-b6fb-d58293acc2bc/2_5.jpg,http://gzhimages.paidanzi.com/cut/287df17b-d323-4558-b6fb-d58293acc2bc/2_6.jpg,http://gzhimages.paidanzi.com/cut/287df17b-d323-4558-b6fb-d58293acc2bc/2_7.jpg,http://gzhimages.paidanzi.com/cut/287df17b-d323-4558-b6fb-d58293acc2bc/2_8.jpg");
        map2.put("cutType", true);
        map2.put("cutNum", 8);
        list.add(map2);
        String s = JSON.toJSONString(list);
        return s;
    }
}
