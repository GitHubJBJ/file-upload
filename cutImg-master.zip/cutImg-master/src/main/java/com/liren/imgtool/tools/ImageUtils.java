package com.liren.imgtool.tools;

import org.springframework.beans.factory.annotation.Autowired;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.LinkedList;

/**
 * @description: 图形处理工具类
 * @author: LiRen
 * @create time: on 2019-10-18 09:19
 **/

public class ImageUtils {

    @Autowired
    private static CutImg cutImg;

    /**
     * 将imgUrl链接转化为InputStream流
     *
     * @param: imgUrl
     * Return: java.io.InputStream
     * @Author: Mr.Wang
     * @Date: 2019/10/18
     */
    public static InputStream imgUrlToInputStream(String imgUrl) throws IOException {
        URL urlImg = new URL(imgUrl);
        InputStream in = urlImg.openStream();
        return in;
    }

    /**
     * 将本地文件转化为BufferImage流
     *
     * @param imgFileUrl
     * @return
     * @throws IOException
     */
    public static BufferedImage ImgFileToBufferImg(String imgFileUrl) throws IOException {
        BufferedImage bi = ImageIO.read(new File(imgFileUrl));
        return bi;
    }

    /**
     * 将InputStream转换为BufferImg流
     *
     * @param: in
     * Return: java.awt.image.BufferedImage
     * @Author: Mr.Wang
     * @Date: 2019/10/18
     */
    public static BufferedImage inStreamToBufferImg(InputStream in) throws IOException {
        BufferedImage bi = ImageIO.read(in);
        return bi;
    }

    /**
     * 切割类型
     * ★★★固定切割宽高，或者平均切割的宽高均不得超过2W px。★★★
     * ★★★错误报告：https://bugs.openjdk.java.net/browse/JDK-7132728 ★★★
     *
     * @return
     * @param: bi   //  BufferedImage流
     * @param: cutType  //   切割类型：
     * <h1>true</h1>：平均切割：   -->  参数中固定切割宽度和高度无效。但是不建议高度切割完成后出现高度大于2W像素。
     * <h1>false</h1>：固定切割，  -->  参数中切割份数、固定切割高度参数均生效。
     * 不能  (cutOffSetWidth == 0 && cols == 0 )|| (cutOffSetHeight == 0 && cows == 0)
     * 优先级：cutOffSetWidth\cutOffSetHeight > cols\rows
     * 默认 cols、和 rows为0
     * @param: cols  // 纵向分割份数：列数
     * @param: rows //  横向分割分数：行数
     * @param: cutOffSetWidth   //  固定切割宽度
     * @param: cutOffSetHeight  //  固定切割高度
     * Return: java.awt.image.BufferedImage //  每一份的切图 BufferedImage 信息
     * @Author: Mr.Wang
     * @Date: 2019/10/18
     */
    public static LinkedList<BufferedImage> cutImgType(BufferedImage bi, Boolean cutType, Integer cols, Integer rows, final Integer cutOffSetWidth, final Integer cutOffSetHeight) throws Exception {
        if (cutType) {
            //  按照原图进行平均切割
            return cutImg.CutAveRangeImg(bi, cols, rows);
        } else {
            //  按照固定宽或者高进行切割
            return cutImg.CutFixRangeImg(bi, cols, rows, cutOffSetWidth, cutOffSetHeight);
        }
    }

    /**
     * BufferedImage -> 转换成 File
     *
     * @param: bi
     * @param: path
     * Return: java.io.File
     * @Author: Mr.Wang
     * @Date: 2019/10/20
     * @return
     */
    public static File BufferedImageToFile(BufferedImage bi, String path) throws IOException {
        return new ImgFile().BufferedImageToFile(bi, path);
    }

    /**
     * BufferedImage -> 转换成 Byte[]
     *
     * @param: bi
     * Return: byte[]
     * @Author: Mr.Wang
     * @Date: 2019/10/20
     */
    public static byte[] BufferedImageToByte(BufferedImage bi) throws IOException {
        return new ImgByte().BufferedImageToByte(bi);
    }

}
