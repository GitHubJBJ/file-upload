package com.liren.imgtool.thread;

/**
 * @description: 多线程返回
 * @author: Mr.Wang
 * @create time: on 2019-10-22 10:55
 **/

public class ClientThread  {

}
