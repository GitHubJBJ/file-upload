package com.liren.imgtool.thread;

import com.alibaba.fastjson.JSON;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.*;

/**
 * join
 *
 * @description: 主线程等待子线程结束后返回。有返回值
 * @author: Mr.Wang
 * @create time: on 2019-10-21 09:42
 **/

public class CutSubImg3 {

    public static void main(String[] args) throws IOException, InterruptedException {
        Vector<Thread> parentThread = new Vector<>();

        long s = System.currentTimeMillis();
        String imgUrl = "C:/lzz/data/1.jpg";
        BufferedImage bi = ImageIO.read(new File(imgUrl));
        final int imgWidth = bi.getWidth();
        final int imgHeight = bi.getHeight();
        System.out.println("imgWidth = " + imgWidth + ",imgHeight:" + imgHeight);
        //  [{"name":"选区1","width":"0.1311","height":"0.1311","xLen":"0.0000","yLen":"0.0000","cutType":false,"cutNum":8},{"name":"选区2","width":"0.1311","height":"0.1311","xLen":"0.0000","yLen":"0.0000","cutType":false,"cutNum":8}]
        String parm = createParm();
        System.out.println("parm = " + parm);
        //  解析成每个都拆分
        List<Map> list = JSON.parseArray(parm, Map.class);
        HashMap<String, Object> hashMap = new HashMap<>();
        for (int i = 0; i < list.size(); i++) {
            Map map = list.get(i);
            Double xLen = Double.valueOf(String.valueOf(map.get("xLen")));
            Double yLen = Double.valueOf(String.valueOf(map.get("yLen")));
            Double capWidth = Double.valueOf(String.valueOf(map.get("width")));
            Double capHeight = Double.valueOf(String.valueOf(map.get("height")));
            boolean cutType = Boolean.parseBoolean(String.valueOf(map.get("cutType")));
            Integer cutNum = Integer.valueOf(String.valueOf(map.get("cutNum")));
            if ((xLen + capWidth) > 1 || (yLen + capHeight) > 1) {
                continue;
            }
            int x = (int) ((xLen > 1) ? imgWidth : xLen * imgWidth);
            int y = (int) ((yLen > 1) ? imgHeight : yLen * imgHeight);
            int w = (int) ((capWidth > 1) ? imgWidth : capWidth * imgWidth);
            int h = (int) ((capHeight > 1) ? imgHeight : capWidth * imgHeight);
            System.out.println(x + "_" + y + "_" + w + "_" + h);
            LinkedList<String> image = getImage(parentThread, bi, cutType, i, cutNum, x, y, w, h);
            hashMap.put(i + "", image);
            for (Thread thread : parentThread) {
                thread.join();
            }
        }
        System.out.println("主线程执行" + hashMap);
        long en = System.currentTimeMillis();
        System.out.println(en - s + "秒");
    }

    /**
     * 按照若干个给定的坐标数据，进行裁剪图片。并切割成若干份
     *
     * @param: imgUrl
     * @param: x
     * @param: y
     * @param: destWidth
     * @param: destHeight
     * Return: void
     * @Author: Mr.Wang
     * @Date: 2019/10/21
     * @return
     */
    private static LinkedList<String> getImage(Vector<Thread> parentThread, BufferedImage bi, boolean cutType, int each, Integer cutNum, Integer x, Integer y, Integer destWidth, Integer destHeight) {
        try {
            if (cutType) {
                //  纵向切图
                destWidth = destWidth / cutNum;
            } else {
                //  横向切图
                destHeight = destHeight / cutNum;
            }
            LinkedList<String> list = new LinkedList<>();
            for (Integer i = 0; i < cutNum; i++) {
                Integer finalDestWidth = destWidth;
                Integer finalDestHeight = destHeight;
                final int j = i;
                Thread childThread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Image image;
                        if (cutType) {
                            image = bi.getSubimage(x + finalDestWidth * j, y, finalDestWidth, finalDestHeight);
                        } else {
                            image = bi.getSubimage(x, y + finalDestHeight * j, finalDestWidth, finalDestHeight);
                        }
//                        System.out.println("destWidth = " + finalDestWidth + "，destHeight = " + finalDestHeight);
                        BufferedImage tag = new BufferedImage(finalDestWidth, finalDestHeight, BufferedImage.TYPE_INT_RGB);
                        Graphics g = tag.getGraphics();
                        g.drawImage(image, 0, 0, finalDestWidth, finalDestHeight, null);
                        g.dispose();
                        String p = "C://lzz//cut//no_" + each + "_" + (j + 1) + ".png";
                        try {
                            ImageIO.write(tag, "JPEG", new File(p));
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        list.add(p);
//                        System.out.println("子线程执行p = " + p);
                    }
                });
                parentThread.add(childThread);
                childThread.start();
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static String createParm() {
        //  开始造数据。
        LinkedList<Map> list = new LinkedList<>();
        Map<String, Object> map1 = new LinkedHashMap<>();

        map1.put("xLen", 0);
        map1.put("yLen", 0);
        map1.put("width", 0.3);
        map1.put("height", 0.3);
        map1.put("capName", "选区1");
        map1.put("cutType", true);
        map1.put("cutNum", 2);
        Map<String, Object> map2 = new LinkedHashMap<>();
        map2.put("xLen", 0.4);
        map2.put("yLen", 0);
        map2.put("width", 0.6);
        map2.put("height", 0.7);
        map2.put("capName", "选区2");
        map2.put("cutType", true);
        map2.put("cutNum", 8);
        Map<String, Object> map3 = new LinkedHashMap<>();
        map3.put("xLen", 0);
        map3.put("yLen", 0.2);
        map3.put("width", 0.6);
        map3.put("height", 0.7);
        map3.put("capName", "选区3");
        map3.put("cutType", true);
        map3.put("cutNum", 8);
        list.add(map1);
        list.add(map2);
        list.add(map3);
        String s = JSON.toJSONString(list);
        return s;
    }

}
