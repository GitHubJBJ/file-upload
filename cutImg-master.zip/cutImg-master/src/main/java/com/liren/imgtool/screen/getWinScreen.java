package com.liren.imgtool.screen;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

/**
 * @description: 获取屏幕的截图
 * @author: Mr.Wang
 * @create time: on 2019-10-23 11:16
 **/

public class getWinScreen {

    public static void main(String[] args) {
        try {
            // 获取屏幕尺寸
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

            // 创建需要截取的矩形区域
            Rectangle rect = new Rectangle(0, 0, screenSize.width, screenSize.height);

            // 截屏操作
            BufferedImage bufImage = new Robot().createScreenCapture(rect);

            // 保存截取的图片
            String p = "C://lzz//cut//no_" + 1 + ".png";
            ImageIO.write(bufImage, "PNG", new File(p));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
