package com.liren.imgtool.thread;


import com.alibaba.fastjson.JSON;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.*;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

/**
 *
 * CyclicBarrier
 *
 * @description: 主线程等待子线程结束后返回。但是线程数量是有要求的。
 * @author: Mr.Wang
 * @create time: on 2019-10-21 09:42
 **/

public class CutSubImg2 {

    public static void main(String[] args) throws IOException, InterruptedException, BrokenBarrierException {
        long s = System.currentTimeMillis();
        String imgUrl = "C:/lzz/data/1.jpg";
        BufferedImage bi = ImageIO.read(new File(imgUrl));
        final int imgWidth = bi.getWidth();
        final int imgHeight = bi.getHeight();
        System.out.println("imgWidth = " + imgWidth + ",imgHeight:" + imgHeight);
        //  [{"name":"选区1","width":"0.1311","height":"0.1311","xLen":"0.0000","yLen":"0.0000","cutType":false,"cutNum":8},{"name":"选区2","width":"0.1311","height":"0.1311","xLen":"0.0000","yLen":"0.0000","cutType":false,"cutNum":8}]

        String parm = createParm();
        System.out.println("parm = " + parm);
        //  解析成每个都拆分
        List<Map> list = JSON.parseArray(parm, Map.class);

        final CyclicBarrier barrier = new CyclicBarrier(3);

        for (int i = 0; i < list.size(); i++) {
            Map map = list.get(i);
            Double xLen = Double.valueOf(String.valueOf(map.get("xLen")));
            Double yLen = Double.valueOf(String.valueOf(map.get("yLen")));
            Double capWidth = Double.valueOf(String.valueOf(map.get("width")));
            Double capHeight = Double.valueOf(String.valueOf(map.get("height")));
            boolean cutType = Boolean.parseBoolean(String.valueOf(map.get("cutType")));
            Integer cutNum = Integer.valueOf(String.valueOf(map.get("cutNum")));
            if ((xLen + capWidth) > 1 || (yLen + capHeight) > 1) {
                continue;
            }
            int x = (int) ((xLen > 1) ? imgWidth : xLen * imgWidth);
            int y = (int) ((yLen > 1) ? imgHeight : yLen * imgHeight);
            int w = (int) ((capWidth > 1) ? imgWidth : capWidth * imgWidth);
            int h = (int) ((capHeight > 1) ? imgHeight : capWidth * imgHeight);
            System.out.println(x + "_" + y + "_" + w + "_" + h);
            final int j = i;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    ArrayList<String> image = getImage(bi, cutType, j, cutNum, x, y, w, h);
                    System.out.println(Thread.currentThread().getName() + ",执行完毕了。。。");
                    //  可以执行插入动作。
                    try {
                        barrier.await();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }
        barrier.await();
        long en = System.currentTimeMillis();
        System.out.println("消耗了：" + (en - s) + "秒");
    }

    /**
     * 按照若干个给定的坐标数据，进行裁剪图片。并切割成若干份
     *
     * @param: imgUrl
     * @param: x
     * @param: y
     * @param: destWidth
     * @param: destHeight
     * Return: void
     * @Author: Mr.Wang
     * @Date: 2019/10/21
     * @return
     */
    private static ArrayList<String> getImage(BufferedImage bi, boolean cutType, int each, Integer cutNum, Integer x, Integer y, Integer destWidth, Integer destHeight) {
        try {
            if (cutType) {
                //  纵向切图
                destWidth = destWidth / cutNum;
            } else {
                //  横向切图
                destHeight = destHeight / cutNum;
            }
            ArrayList<String> list = new ArrayList<>();

            for (Integer i = 0; i < cutNum; i++) {
//                final int j = i;
                Image image;
                if (cutType) {
                    image = bi.getSubimage(x + destWidth * i, y, destWidth, destHeight);
                } else {
                    image = bi.getSubimage(x, y + destHeight * i, destWidth, destHeight);
                }
                BufferedImage tag = new BufferedImage(destWidth, destHeight, BufferedImage.TYPE_INT_RGB);
                Graphics g = tag.getGraphics();
                g.drawImage(image, 0, 0, destWidth, destHeight, null);
                g.dispose();

                String p = "C://lzz//cut//no_" + each + "_" + i + 1 + ".png";
                try {
                    ImageIO.write(tag, "JPEG", new File(p));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                list.add(p);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    private static String createParm() {
        //  开始造数据。
        LinkedList<Map> list = new LinkedList<>();
        Map<String, Object> map1 = new LinkedHashMap<>();

        map1.put("xLen", 0);
        map1.put("yLen", 0);
        map1.put("width", 0.3);
        map1.put("height", 0.3);
        map1.put("capName", "选区1");
        map1.put("cutType", true);
        map1.put("cutNum", 2);
        Map<String, Object> map2 = new LinkedHashMap<>();
        map2.put("xLen", 0.4);
        map2.put("yLen", 0);
        map2.put("width", 0.6);
        map2.put("height", 0.7);
        map2.put("capName", "选区2");
        map2.put("cutType", true);
        map2.put("cutNum", 8);
        Map<String, Object> map3 = new LinkedHashMap<>();
        map3.put("xLen", 0);
        map3.put("yLen", 0.2);
        map3.put("width", 0.6);
        map3.put("height", 0.7);
        map3.put("capName", "选区3");
        map3.put("cutType", true);
        map3.put("cutNum", 8);
        list.add(map1);
        list.add(map2);
        list.add(map3);
        String s = JSON.toJSONString(list);
        return s;
    }

}
