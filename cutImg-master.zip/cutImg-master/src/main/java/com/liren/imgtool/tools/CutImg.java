package com.liren.imgtool.tools;

import com.liren.imgtool.exception.EmImgToolError;
import com.liren.imgtool.exception.ImgToolException;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.LinkedList;

/**
 * #ToDO ：是否开启线程、是否进行hutool
 * @description: 分割图片工具类
 * @author: Mr.Wang
 * @create time: on 2019-10-18 13:44
 **/

public class CutImg {

    private static final Integer MAX_SIZE = 20000;

    /** 
     *  平均切割
     *
     * @param: bi
     * @param: cutWidthNum  --> 纵向切割
     * @param: cutHeightNum --> 横向切割
     * Return: java.awt.image.BufferedImage 
     * @Author: Mr.Wang
     * @Date: 2019/10/18
     * @return
     */ 
    protected static LinkedList<BufferedImage> CutAveRangeImg(BufferedImage bi, Integer cols, Integer rows) throws Exception {
        //  原图的宽高
        final int width = bi.getWidth();
        final int height = bi.getHeight();
        //  每一份的宽度和高度
        int destWidth = width / cols;   //  j
        int destHeight = height / rows; //  i
        //  如果每份的值大于2W。则会报错。
        if (destWidth > MAX_SIZE || destHeight > MAX_SIZE) {
            throw new ImgToolException(EmImgToolError.JDK_BUGS_ARRAY_OUT_OF);
        }
        LinkedList<BufferedImage> biList = new LinkedList<>();
        for (Integer i = 0; i < rows; i++) {
            for (Integer j = 0; j < cols; j++) {
                {
                    // 四个参数分别为图像起点坐标和宽高
                    Image image = bi.getSubimage(j * destWidth, i * destHeight, destWidth, destHeight);
                    BufferedImage tag = new BufferedImage(destWidth, destHeight, BufferedImage.TYPE_INT_RGB);
                    Graphics g = tag.getGraphics();
                    g.drawImage(image, 0, 0, destWidth,  destHeight, null);
                    g.dispose();
//                    ByteArrayOutputStream byOut = new ByteArrayOutputStream();
//                    ImageIO.write(tag, "JPEG", byOut);
//                    byte[] imgBytes = byOut.toByteArray();
//                    String p = "C://lzz//cut//no_" + i + "_" + j + ".png";
//                    ImageIO.write(tag, "JPEG", new File(p));
//                    System.out.println("图片保存在本地地址： " + p);
                    biList.add(tag);
                }
            }
        }
        return biList;
    }
    protected static LinkedList<BufferedImage> CutFixRangeImg(BufferedImage bi, Integer cols, Integer rows, Integer cutWidth, Integer cutHeight) throws Exception {

        int imgWidth = bi.getWidth();
        int imgHeight = bi.getHeight();
        //  判断  切割的份数
        //  竖着切
        if (null != cutWidth || 0 != cutWidth){
            cols = (imgWidth > cutWidth) ? imgWidth / cutWidth + 1 : 1;
        } else if (null == cols || 0 == cols){
            throw new ImgToolException(EmImgToolError.WIDTH_PARM_ERROR);
        }
        //  横着切
        if (null != cutHeight || 0 != cutHeight){
            rows = (imgHeight > cutHeight) ? imgHeight / cutHeight + 1 : 1;
        } else if (null == rows || 0 == rows){
            throw new ImgToolException(EmImgToolError.HEIGHT_PARM_ERROR);
        }

        System.out.println("cols = " + cols + ", rows = " + rows + ", cutWidth = " + cutWidth + ", cutHeight = " + cutHeight);
//        System.out.println("imgHeight：" + imgHeight + "，imgWidth:" + imgWidth + ",destWidth:" + destWidth + ",destHeight = " + destHeight);
        LinkedList<BufferedImage> biList = new LinkedList<>();
        for (Integer i = 0; i < rows; i++) {
            //  判断切割的宽高
            int destWidth = 1;
            int destHeight = 1;
            if (cols == 1) {
                destWidth = imgWidth;
            } else {
                destWidth = cutWidth;
            }
            if (rows == 1) {
                destHeight = imgHeight;
            } else {
                destHeight = cutHeight;
            }
            if (rows - 1 == i ) {
                //  说明到了边界。那么要判断是谁的边界
                    destHeight = imgHeight - destHeight * i;
            }
            for (Integer j = 0; j < cols; j++) {
                //  最后一次循环的高度和宽度要发生变化
                System.out.println(i + " " + j);
                System.out.println("imgHeight：" + imgHeight + "，imgWidth:" + imgWidth + ",destWidth:" + destWidth + ",destHeight = " + destHeight);

                if (cols - 1 == j ) {
                    destWidth = imgWidth - destWidth * j;
                }

                System.out.println("imgHeight：" + imgHeight + "，imgWidth:" + imgWidth + ",destWidth:" + destWidth + ",destHeight = " + destHeight);
                Image image = bi.getSubimage(j * cutWidth, i * cutHeight, destWidth, destHeight);
                BufferedImage tag = new BufferedImage(destWidth, destHeight, BufferedImage.TYPE_INT_RGB);
                Graphics g = tag.getGraphics();
                g.drawImage(image, 0, 0, destWidth,  destHeight, null);
                g.dispose();
                biList.add(tag);
            }
        }
        return biList;
    }

}
